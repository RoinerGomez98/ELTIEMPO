CREATE DATABASE ELTIEMPO
GO
USE ELTIEMPO
GO

if not exists(select * from sys.tables where name='Ciudad')
BEGIN
CREATE TABLE Ciudad(
CODCIUDAD INT PRIMARY KEY,
DESCRIPCION VARCHAR(50)
);
END
GO

if not exists(select * from sys.tables where name='Vendedor')
begin
CREATE TABLE Vendedor(
CODIGO INT PRIMARY KEY,
NOMBRE VARCHAR(50),
APELLIDO VARCHAR(50),
NUMERO_IDENTIFICACION VARCHAR(20),
CODCIUDAD INT
CONSTRAINT FK_CIUDAD FOREIGN KEY (CODCIUDAD) REFERENCES CIUDAD (CODCIUDAD),
)
END
GO

IF NOT EXISTS(SELECT * FROM Ciudad where CODCIUDAD = 1)
begin
insert into Ciudad(CODCIUDAD,DESCRIPCION) values(1,'Bogot�')
end
go

IF NOT EXISTS(SELECT * FROM Ciudad where CODCIUDAD = 2)
begin
insert into Ciudad(CODCIUDAD,DESCRIPCION) values(2,'Cali')
end
go
